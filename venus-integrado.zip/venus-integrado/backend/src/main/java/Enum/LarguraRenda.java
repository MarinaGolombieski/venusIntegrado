package Enum;

public enum LarguraRenda {
	FINA,
    MEDIA,
    LARGA
}
