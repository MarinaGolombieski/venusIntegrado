package Enum;

public enum EstadoProduto {
    COMO_NOVO,
    POUCO_USADO,
    USADO
}