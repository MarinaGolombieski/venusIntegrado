package Enum;

public enum TipoProduto {
	 NOVO,
	 SEMINOVO
}
