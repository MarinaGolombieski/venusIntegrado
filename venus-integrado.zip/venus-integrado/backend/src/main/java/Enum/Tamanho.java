package Enum;

public enum Tamanho {
    PP,
    P,
    M,
    G,
    GG,
    XG
}