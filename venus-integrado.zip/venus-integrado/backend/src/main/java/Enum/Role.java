package Enum;

public enum Role {
    CLIENTE,
    ADMIN
}