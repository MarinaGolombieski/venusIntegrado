package Enum;

public enum TipoAlteracao {
	 	BORDADO_DESENHO,
	    BORDADO_ESCRITA,
	    APLICACAO_RENDA,
	    TINGIMENTO,
	    ALTERACAO_MANGA
}
