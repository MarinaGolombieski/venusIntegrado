package Enum;

public enum StatusPagamento {
	 	PENDENTE,
	    APROVADO,
	    RECUSADO,
	    CANCELADO
}
