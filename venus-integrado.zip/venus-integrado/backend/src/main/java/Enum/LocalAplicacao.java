package Enum;

public enum LocalAplicacao {
	PEITO,
	COSTAS,
	MANGA,
	BARRA
}
