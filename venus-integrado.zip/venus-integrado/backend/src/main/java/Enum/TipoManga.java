package Enum;

public enum TipoManga {
	 	CURTA,
	    TRES_QUARTOS,
	    LONGA,
	    SEM_MANGA
}
