package Enum;

public enum Fonte {
	 	SERIF,
	 	SCRIPT,
	    MODERNA,
	    
}
