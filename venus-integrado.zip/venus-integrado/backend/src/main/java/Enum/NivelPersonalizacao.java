package Enum;

public enum NivelPersonalizacao {
	DETALHE,
    TRANSFORMACAO
}
