package Enum;

public enum Desenho {
	BORBOLETA,
    RAIO,
    FLOR,
    ESTRELA,
    CORACAO,
    LUA,
    SOL,
    PATINHA,
    SORRISO,
    COROA,
    OLHO
}
