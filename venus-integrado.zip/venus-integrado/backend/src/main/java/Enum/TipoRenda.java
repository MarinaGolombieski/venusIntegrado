package Enum;

public enum TipoRenda {
	 	FLORAL,
	    BOLHINHA,
	    TULE_BORDADA,
	    GUIPIR
}
