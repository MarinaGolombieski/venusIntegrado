package Enum;

public enum MetodoPagamento {
    PIX,
    CARTAO,
    BOLETO
}
