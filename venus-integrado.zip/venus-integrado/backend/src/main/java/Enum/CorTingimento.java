package Enum;

public enum CorTingimento {
	 	PRETO,
	    BRANCO,
	    VERMELHO,
	    AZUL,
	    VERDE,
	    AMARELO,
	    ROSA,
	    LILAS,
	    MARROM,
	    CINZA,
	    BEGE
}
