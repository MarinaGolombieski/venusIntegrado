package Enum;

public enum TamanhoBordado {
	 	PEQUENO,
	    MEDIO,
	    GRANDE
}
