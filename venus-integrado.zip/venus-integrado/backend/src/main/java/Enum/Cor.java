package Enum;

public enum Cor {
	PRETO,
    BRANCO,
    VERMELHO,
    AZUL,
    VERDE,
    AMARELO,
    ROSA
}
