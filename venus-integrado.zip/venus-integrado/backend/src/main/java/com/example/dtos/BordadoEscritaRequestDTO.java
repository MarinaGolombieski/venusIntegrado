package com.example.dtos;

public class BordadoEscritaRequestDTO {

}
