package com.example.dtos;
import java.math.BigDecimal; import java.util.List; import Enum.*;
public class ProdutoResponseDTO {
    private Long id; private String nome; private String descricao; private BigDecimal preco; private int estoque;
    private TipoProduto tipo; private EstadoProduto estado; private Long categoriaId; private Tamanho tamanho; private List<Long> imagemIds;
    public ProdutoResponseDTO() {}
    public Long getId(){return id;} public void setId(Long v){id=v;} public String getNome(){return nome;} public void setNome(String v){nome=v;}
    public String getDescricao(){return descricao;} public void setDescricao(String v){descricao=v;} public BigDecimal getPreco(){return preco;} public void setPreco(BigDecimal v){preco=v;}
    public int getEstoque(){return estoque;} public void setEstoque(int v){estoque=v;} public TipoProduto getTipo(){return tipo;} public void setTipo(TipoProduto v){tipo=v;}
    public EstadoProduto getEstado(){return estado;} public void setEstado(EstadoProduto v){estado=v;} public Long getCategoriaId(){return categoriaId;} public void setCategoriaId(Long v){categoriaId=v;}
    public Tamanho getTamanho(){return tamanho;} public void setTamanho(Tamanho v){tamanho=v;} public List<Long> getImagemIds(){return imagemIds;} public void setImagemIds(List<Long> v){imagemIds=v;}
}
