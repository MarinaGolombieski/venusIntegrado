package com.example.dtos;

public class AplicacaoRendaResponseDTO {

}
