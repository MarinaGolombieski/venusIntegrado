package com.example.dtos;

public class AplicacaoRendaRequestDTO {

}
