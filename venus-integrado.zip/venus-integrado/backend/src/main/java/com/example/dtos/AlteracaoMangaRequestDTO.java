package com.example.dtos;

public class AlteracaoMangaRequestDTO {

}
