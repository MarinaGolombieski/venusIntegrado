package com.example.repositories;
import org.springframework.data.jpa.repository.JpaRepository;
import com.example.entities.ItemPedido;
public interface ItemPedidoRepository extends JpaRepository<ItemPedido, Long> {}
