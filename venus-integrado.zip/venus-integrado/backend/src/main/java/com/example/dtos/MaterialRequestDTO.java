package com.example.dtos;

public class MaterialRequestDTO {
	private String nome;

    public MaterialRequestDTO() {
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }
}
