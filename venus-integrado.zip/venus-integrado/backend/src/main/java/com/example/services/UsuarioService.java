package com.example.services;

import java.util.List;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;
import com.example.dtos.*;
import com.example.entities.Usuario;
import com.example.repositories.UsuarioRepository;
import Enum.Role;

@Service
public class UsuarioService {
    private final UsuarioRepository repo;
    private final BCryptPasswordEncoder encoder = new BCryptPasswordEncoder();

    public UsuarioService(UsuarioRepository repo){this.repo=repo;}

    public List<UsuarioResponseDTO> listarTodos(){return repo.findAll().stream().map(this::dto).toList();}
    public Usuario entity(Long id){return repo.findById(id).orElseThrow(()->new RuntimeException("Usuário não encontrado"));}
    public UsuarioResponseDTO buscar(Long id){return dto(entity(id));}

    public UsuarioResponseDTO salvar(UsuarioRequestDTO d){
        if(d==null||d.getUsername()==null||d.getUsername().isBlank()||d.getSenha()==null||d.getSenha().isBlank())
            throw new RuntimeException("username e senha são obrigatórios");
        if(repo.findByUsername(d.getUsername().trim()).isPresent()) throw new RuntimeException("Usuário já cadastrado");
        Usuario u=new Usuario();
        u.setUsername(d.getUsername().trim());
        u.setSenha(encoder.encode(d.getSenha()));
        u.setRole(d.getRole()==null?Role.CLIENTE:d.getRole());
        return dto(repo.save(u));
    }

    public UsuarioResponseDTO atualizar(Long id,UsuarioRequestDTO d){
        Usuario u=entity(id);
        if(d.getUsername()!=null&&!d.getUsername().isBlank())u.setUsername(d.getUsername().trim());
        if(d.getSenha()!=null&&!d.getSenha().isBlank())u.setSenha(encoder.encode(d.getSenha()));
        if(d.getRole()!=null)u.setRole(d.getRole());
        return dto(repo.save(u));
    }

    public LoginResponseDTO login(LoginRequestDTO d){
        if(d==null||d.getUsername()==null||d.getSenha()==null) throw new RuntimeException("username e senha são obrigatórios");
        Usuario u=repo.findByUsername(d.getUsername().trim()).orElseThrow(()->new RuntimeException("Usuário ou senha inválidos"));
        if(!encoder.matches(d.getSenha(),u.getSenha())) throw new RuntimeException("Usuário ou senha inválidos");
        return new LoginResponseDTO(u.getIdUsuario(),u.getUsername(),u.getRole());
    }

    public void deletar(Long id){repo.delete(entity(id));}
    private UsuarioResponseDTO dto(Usuario u){UsuarioResponseDTO d=new UsuarioResponseDTO();d.setIdUsuario(u.getIdUsuario());d.setUsername(u.getUsername());d.setRole(u.getRole());return d;}
}
