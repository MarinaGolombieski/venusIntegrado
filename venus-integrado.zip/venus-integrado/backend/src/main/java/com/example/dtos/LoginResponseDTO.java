package com.example.dtos;
import Enum.Role;
public class LoginResponseDTO {
    private Long idUsuario;
    private String username;
    private Role role;
    public LoginResponseDTO(){}
    public LoginResponseDTO(Long id,String username,Role role){this.idUsuario=id;this.username=username;this.role=role;}
    public Long getIdUsuario(){return idUsuario;}
    public String getUsername(){return username;}
    public Role getRole(){return role;}
}
