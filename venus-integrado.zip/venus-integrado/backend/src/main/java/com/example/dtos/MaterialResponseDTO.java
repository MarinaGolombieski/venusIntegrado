package com.example.dtos;

public class MaterialResponseDTO {
	private Long idMaterial;
    private String nome;

    public MaterialResponseDTO() {
    }

    public Long getIdMaterial() {
        return idMaterial;
    }

    public void setIdMaterial(Long idMaterial) {
        this.idMaterial = idMaterial;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }
}
