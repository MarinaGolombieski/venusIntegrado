package com.example.dtos;

import Enum.Role;

public class UsuarioResponseDTO {
	 private Long idUsuario;
	    private String username;
	    private Role role;

	    public UsuarioResponseDTO() {
	    }

	    public Long getIdUsuario() {
	        return idUsuario;
	    }

	    public void setIdUsuario(Long idUsuario) {
	        this.idUsuario = idUsuario;
	    }

	    public String getUsername() {
	        return username;
	    }

	    public void setUsername(String username) {
	        this.username = username;
	    }

	    public Role getRole() {
	        return role;
	    }
	    public void setRole(Role role) {
	        this.role = role;
	    }

}
