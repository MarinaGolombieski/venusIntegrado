package com.example.dtos;

public class BordadoDesenhoRequestDTO {

}
