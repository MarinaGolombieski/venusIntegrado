package com.example.dtos;
public class ImagemResponseDTO { private Long idImagem; private Long produtoId; public ImagemResponseDTO(){} public Long getIdImagem(){return idImagem;} public void setIdImagem(Long v){idImagem=v;} public Long getProdutoId(){return produtoId;} public void setProdutoId(Long v){produtoId=v;} }
