package com.example.dtos;

public class TingimentoResponseDTO {

}
