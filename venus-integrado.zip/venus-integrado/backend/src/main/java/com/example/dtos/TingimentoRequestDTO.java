package com.example.dtos;

public class TingimentoRequestDTO {

}
