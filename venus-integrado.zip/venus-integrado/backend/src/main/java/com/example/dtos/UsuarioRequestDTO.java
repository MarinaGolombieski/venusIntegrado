package com.example.dtos;

import Enum.Role;

public class UsuarioRequestDTO {
	 private String username;
	    private String senha;
	    private Role role;

	    public UsuarioRequestDTO() {
	    }

	    public String getUsername() {
	        return username;
	    }

	    public void setUsername(String username) {
	        this.username = username;
	    }

	    public String getSenha() {
	        return senha;
	    }

	    public void setSenha(String senha) {
	        this.senha = senha;
	    }
	    public Role getRole() {
	        return role;
	    }

	    public void setRole(Role role) {
	        this.role = role;
	    }

}
