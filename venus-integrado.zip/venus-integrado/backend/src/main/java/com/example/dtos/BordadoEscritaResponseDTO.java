package com.example.dtos;

public class BordadoEscritaResponseDTO {

}
