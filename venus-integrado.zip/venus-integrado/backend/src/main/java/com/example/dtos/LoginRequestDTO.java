package com.example.dtos;
public class LoginRequestDTO {
    private String username;
    private String senha;
    public String getUsername(){return username;}
    public void setUsername(String v){username=v;}
    public String getSenha(){return senha;}
    public void setSenha(String v){senha=v;}
}
