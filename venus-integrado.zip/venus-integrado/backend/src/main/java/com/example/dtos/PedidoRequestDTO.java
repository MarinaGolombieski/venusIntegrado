package com.example.dtos;
public class PedidoRequestDTO { private Long carrinhoId; public PedidoRequestDTO(){} public Long getCarrinhoId(){return carrinhoId;} public void setCarrinhoId(Long v){carrinhoId=v;} }
