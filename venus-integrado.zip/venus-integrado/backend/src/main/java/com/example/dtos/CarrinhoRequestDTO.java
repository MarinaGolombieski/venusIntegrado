package com.example.dtos;

public class CarrinhoRequestDTO {
	private Long usuarioId;

    public CarrinhoRequestDTO() {
    }

    public Long getUsuarioId() {
        return usuarioId;
    }

    public void setUsuarioId(Long usuarioId) {
        this.usuarioId = usuarioId;
    }
}
