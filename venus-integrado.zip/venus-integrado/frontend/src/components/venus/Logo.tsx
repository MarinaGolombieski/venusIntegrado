export function LogoMark({ className = "h-6 w-6" }: { className?: string }) {
  return (
    <svg viewBox="0 0 40 40" className={className} fill="none" stroke="currentColor" strokeWidth="2" aria-hidden>
      <circle cx="20" cy="20" r="17" />
      <path d="M20 9l3 7 7 .5-5.4 4.6 1.8 7L20 24.3 13.6 28l1.8-7L10 16.5l7-.5z" strokeLinejoin="round" />
    </svg>
  );
}

export function Logo() {
  return (
    <span className="inline-flex items-center gap-1.5 text-primary">
      <LogoMark className="h-5 w-5" />
      <span className="font-display text-base font-bold">WalkWorld</span>
    </span>
  );
}
