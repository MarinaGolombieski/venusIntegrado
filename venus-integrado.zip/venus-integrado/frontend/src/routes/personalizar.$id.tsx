import { createFileRoute, Link, notFound, useNavigate } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { ChevronRight, Plus, Sparkles } from "lucide-react";
import { AppHeader, SideTabs } from "@/components/venus/AppHeader";
import { ALL_SIZES, fetchProductFromApi, getProduct, type Product, type Size } from "@/data/products";
import { COLORS, COLOR_SWATCH, TINGIMENTO_COLORS, CUSTOMIZATIONS, type CustomizationOption } from "@/data/customizations";
import { brl } from "@/lib/pricing";
import { useStore } from "@/lib/store";
import { aiApi } from "@/services/venusApi";

export const Route = createFileRoute("/personalizar/$id")({
  loader: async ({ params }) => {
    try { const p = await fetchProductFromApi(params.id); if (!p.customizable) throw notFound(); return { id: p.id }; }
    catch { const p = getProduct(params.id); if (!p || !p.customizable) throw notFound(); return { id: p.id }; }
  },
  head: () => ({ meta: [
    { title: "Personalizar peça — Vênus" }, { name: "description", content: "Bordado, tingimento, renda e alteração de manga." },
  ] }),
  notFoundComponent: () => <div className="p-16 text-center">Peça não disponível para personalização. <Link to="/personalizar" className="text-primary underline">Ver peças</Link></div>,
  component: Personalizar,
});

function Personalizar() {
  const { id } = Route.useParams();
  const [product, setProduct] = useState<Product>(() => getProduct(id)!);
  const nav = useNavigate();
  const { addToCart, addCustomization } = useStore();
  const [level, setLevel] = useState<1 | 2 | null>(null);
  const [opt, setOpt] = useState<CustomizationOption | null>(null);
  const [details, setDetails] = useState<Record<string, string>>({});
  const [size, setSize] = useState<Size | null>(null);
  const [erro, setErro] = useState("");
  const [aiMessage, setAiMessage] = useState("");
  const [aiImage, setAiImage] = useState<string | null>(null);

  useEffect(() => { void fetchProductFromApi(id).then(setProduct).catch(() => undefined); }, [id]);

  const price = (product?.priceCents ?? 0) + (opt?.extraCents ?? 0);

  const requestAiPreview = async () => {
    if (!opt || !product.backendId) return;
    setAiMessage("Gerando prévia...");
    try {
      const r = await aiApi.preview({ produtoId: product.backendId, tipoAlteracao: opt.id, detalhes: details });
      setAiImage(r.imageUrl); setAiMessage(r.message);
    } catch (e) { setAiImage(null); setAiMessage(e instanceof Error ? e.message : "A prévia por IA ainda não está configurada."); }
  };

  const confirm = async () => {
    if (!opt) return setErro("Escolha uma personalização.");
    const missing = opt.fields.find((f) => !details[f.id]?.trim());
    if (missing) return setErro(`Preencha: ${missing.label}.`);
    if (!size) return setErro("Escolha um tamanho.");
    try {
      const created = await addToCart({ productId: id, size, quantity: 1, customizations: [] });
      if (!created.backendItemId) throw new Error("Não foi possível identificar o item do carrinho.");
      await addCustomization(created.backendItemId, { tipo: opt.id, ...details });
      nav({ to: "/pagamento" });
    } catch (e) { setErro(e instanceof Error ? e.message : "Não foi possível salvar a personalização."); }
  };

  return (
    <div className="min-h-screen pb-16">
      <AppHeader title={opt ? `Nível ${opt.level} · ${opt.level === 1 ? "Detalhes" : "Transformação"}` : "Personalize sua peça"} subtitle={opt?.name ?? "Escolha o nível de personalização"} /><SideTabs />
      <main className="mx-auto grid max-w-6xl gap-8 px-4 py-6 sm:px-8 md:grid-cols-[1fr_1.4fr]">
        <aside className="panel bg-blush text-center">
          <img src={product.image} alt={product.name} width={768} height={960} className="mx-auto aspect-[4/5] w-full max-w-[220px] rounded-lg object-cover" />
          <p className="mt-2 text-sm font-bold">{product.name}</p>
          <p className="text-sm font-extrabold text-primary" aria-live="polite">{brl(price)}</p>
          {opt && <p className="text-[11px] text-muted-foreground">inclui {opt.name}: +{brl(opt.extraCents)}</p>}
        </aside>

        <section className="space-y-4">
          {!opt && <>
            <p className="text-xs text-muted-foreground">Escolha o nível de personalização:</p>
            {[1, 2].map((l) => <div key={l}>
              <button onClick={() => setLevel(level === l ? null : (l as 1 | 2))} className="panel flex w-full items-start justify-between text-left">
                <span><span className="text-xs font-extrabold text-primary">NÍVEL {l} – {l === 1 ? "DETALHES" : "TRANSFORMAÇÃO"}</span><span className="block text-xs">{l === 1 ? "Desenhos e escritas aplicados à peça." : "Tingimento, renda ou alteração de manga."}</span></span>
                <Plus className="h-4 w-4 text-primary" />
              </button>
              {level === l && <div className="mt-3 grid gap-3 sm:grid-cols-2">
                {CUSTOMIZATIONS.filter((c) => c.level === l).map((c) => <button key={c.id} onClick={() => { setOpt(c); setDetails({}); setErro(""); setAiMessage(""); setAiImage(null); }} className="panel text-left transition hover:ring-2 hover:ring-primary">
                  <span className="flex justify-between text-sm font-bold text-primary">{c.name}<ChevronRight className="h-4 w-4" /></span><span className="mt-1 block text-xs">{c.description}</span><span className="mt-2 block text-xs font-bold">+{brl(c.extraCents)}</span>
                </button>)}
              </div>}
            </div>)}
          </>}

          {opt && <div className="space-y-5">
            <button onClick={() => setOpt(null)} className="text-xs font-semibold text-primary underline">← Trocar personalização</button>
            {opt.fields.map((f) => <div key={f.id}>
              <p className="mb-2 text-sm font-bold text-primary">{f.label}</p>
              {f.type === "text" && <input className="field" maxLength={50} placeholder="Digite aqui" value={details[f.id] ?? ""} onChange={(e) => setDetails({ ...details, [f.id]: e.target.value })} />}
              {f.type === "choice" && <div className="flex flex-wrap gap-2">{f.options!.map((o) => <button key={o} onClick={() => setDetails({ ...details, [f.id]: o })} className={`chip ${details[f.id] === o ? "chip-active" : ""}`}>{o.replaceAll("_", " ")}</button>)}</div>}
              {f.type === "color" && <div className="flex flex-wrap gap-2">{(opt.id === "TINGIMENTO" ? TINGIMENTO_COLORS : COLORS).map((c) => <button key={c} aria-label={c} title={c} onClick={() => setDetails({ ...details, [f.id]: c })} style={{ background: COLOR_SWATCH[c] }} className={`h-8 w-8 rounded-full border ${details[f.id] === c ? "ring-2 ring-primary ring-offset-2" : ""}`} />)}</div>}
            </div>)}

            <div><p className="mb-2 text-sm font-bold text-primary">Tamanho</p><div className="flex gap-2">{ALL_SIZES.map((s) => <button key={s} disabled={product.stock[s] === 0} onClick={() => setSize(s)} className={`chip ${size === s ? "chip-active" : ""} disabled:line-through disabled:opacity-40`}>{s}</button>)}</div></div>

            <div className="rounded-xl border border-primary/20 bg-cream p-4">
              <div className="flex items-center gap-2 text-sm font-bold text-primary"><Sparkles className="h-4 w-4" /> Prévia com IA</div>
              <p className="mt-1 text-[11px] text-muted-foreground">A IA poderá mostrar uma simulação da peça depois da alteração escolhida. A chave do provedor fica no Back-end.</p>
              <button type="button" onClick={() => void requestAiPreview()} className="btn-wine mt-3">Gerar prévia</button>
              {aiMessage && <p className="mt-2 text-xs">{aiMessage}</p>}
              {aiImage && <img src={aiImage} alt="Prévia da personalização gerada por IA" className="mt-3 max-h-72 w-full rounded-lg object-contain" />}
            </div>

            {erro && <p className="text-xs font-semibold text-destructive">{erro}</p>}
            <button onClick={() => void confirm()} className="btn-primary">Adicionar ao carrinho · {brl(price)}</button>
          </div>}
        </section>
      </main>
    </div>
  );
}
