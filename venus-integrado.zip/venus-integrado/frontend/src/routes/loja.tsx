import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useMemo, useState } from "react";
import { AppHeader, SideTabs } from "@/components/venus/AppHeader";
import { ProductCard } from "@/components/venus/ProductCard";
import { PRODUCTS, fetchProductsFromApi, type Product } from "@/data/products";
import { useStore } from "@/lib/store";

export const Route = createFileRoute("/loja")({
  head: () => ({ meta: [
    { title: "Catálogo — Vênus" }, { name: "description", content: "Peças novas e seminovas para personalizar." },
    { property: "og:title", content: "Catálogo — Vênus" }, { property: "og:description", content: "Peças novas e seminovas para personalizar." },
  ] }),
  component: Loja,
});

function Loja() {
  const { user } = useStore();
  const [products, setProducts] = useState<Product[]>(PRODUCTS);
  const [cond, setCond] = useState("Todas"); const [q, setQ] = useState(""); const [max, setMax] = useState(100);
  useEffect(() => { void fetchProductsFromApi().then(setProducts).catch((e) => console.warn("API indisponível; usando dados demonstrativos", e)); }, []);
  const list = useMemo(() => products.filter((p) =>
    (cond === "Todas" || p.condition === cond) && p.priceCents <= max * 100 && p.name.toLowerCase().includes(q.toLowerCase())), [products, cond, q, max]);

  return (
    <div className="min-h-screen pb-16">
      <AppHeader back={false} />
      <SideTabs />
      <main className="mx-auto max-w-6xl px-4 sm:px-8">
        <h2 className="mt-4 text-lg font-extrabold text-primary">Olá{user ? `, ${user.name}` : ""}!</h2>
        <p className="text-xs text-muted-foreground">O que vamos criar hoje?</p>
        <div className="mt-5 flex flex-wrap items-center gap-2">
          {["Todas", "Novo", "Seminovo"].map((c) => <button key={c} onClick={() => setCond(c)} className={`chip ${cond === c ? "chip-active" : ""}`}>{c === "Todas" ? "Todas" : c + "s"}</button>)}
          <input aria-label="Buscar" placeholder="Buscar peça..." className="field w-44 py-1.5" value={q} onChange={(e) => setQ(e.target.value)} />
          <label className="flex items-center gap-2 text-xs">Até R$ {max}
            <input type="range" min={30} max={100} value={max} onChange={(e) => setMax(+e.target.value)} className="accent-primary" /></label>
        </div>
        {list.length === 0 ? (
          <p className="mt-16 text-center text-sm text-muted-foreground">Nenhuma peça encontrada com esses filtros.</p>
        ) : (
          <div className="mt-8 grid grid-cols-2 gap-6 sm:grid-cols-3 lg:grid-cols-4">
            {list.map((p) => <ProductCard key={p.id} product={p} />)}
          </div>
        )}
        <p className="mt-10 text-center text-[11px] text-muted-foreground">Fotos demonstrativas — serão substituídas pelas fotos reais das peças.</p>
      </main>
    </div>
  );
}
