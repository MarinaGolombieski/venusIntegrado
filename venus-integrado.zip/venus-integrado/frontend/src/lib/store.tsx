import { createContext, useContext, useEffect, useState, type ReactNode } from "react";
import { cartApi, customizationApi, orderApi, paymentApi, type BackendCart, type BackendCartItem, type BackendUser, type PersonalizationPayload } from "@/services/venusApi";

export interface CartItem {
  key: string;
  backendItemId?: number;
  cartId?: number;
  productId: string;
  size: string;
  quantity: number;
  customizations: { optionId: string; details: Record<string, string>; backendId?: number }[];
  subtotalCents?: number;
}

export interface Order {
  id: string;
  createdAt: string;
  items: CartItem[];
  totalCents: number;
  payment: "Pix" | "Cartão" | "Boleto";
  status: "Pendente" | "Pago" | "Em produção" | "Enviado" | "Entregue";
  hasCustomization: boolean;
}

interface User { idUsuario: number; name: string; email: string }

interface Store {
  user: User | null;
  setUser: (u: User | null) => void;
  cart: CartItem[];
  cartId: number | null;
  refreshCart: () => Promise<void>;
  addToCart: (i: Omit<CartItem, "key">) => Promise<CartItem>;
  addCustomization: (itemId: number, payload: Omit<PersonalizationPayload, "itemCarrinhoId">) => Promise<void>;
  updateQty: (key: string, q: number) => Promise<void>;
  removeItem: (key: string) => Promise<void>;
  clearCart: () => void;
  orders: Order[];
  placeOrder: (payment: Order["payment"]) => Promise<Order>;
}

const Ctx = createContext<Store | null>(null);
const load = <T,>(k: string, d: T): T => { try { const v = localStorage.getItem(k); return v ? JSON.parse(v) : d; } catch { return d; } };

const paymentEnum = (p: Order["payment"]) => p === "Cartão" ? "CARTAO" : p === "Boleto" ? "BOLETO" : "PIX";
const statusLabel = (s: string): Order["status"] => ({ PENDENTE: "Pendente", PAGO: "Pago", ENVIADO: "Enviado", ENTREGUE: "Entregue", CANCELADO: "Pendente" }[s] as Order["status"] ?? "Pendente");

function detailsFromCustomization(c: BackendCartItem["personalizacoes"][number]) {
  const details: Record<string, string> = {};
  if (c.desenho) details.desenho = c.desenho;
  if (c.cor) details.cor = c.cor;
  if (c.tamanhoBordado) details.tamanho = c.tamanhoBordado;
  if (c.localAplicacao) details.posicao = c.localAplicacao;
  if (c.texto) details.texto = c.texto;
  if (c.fonte) details.fonte = c.fonte;
  if (c.tipoRenda) details.tipoRenda = c.tipoRenda;
  if (c.larguraRenda) details.larguraRenda = c.larguraRenda;
  if (c.corTingimento) details.corTingimento = c.corTingimento;
  if (c.tipoManga) details.tipoManga = c.tipoManga;
  return details;
}

function mapCart(data: BackendCart): CartItem[] {
  return data.itens.map((i) => ({
    key: String(i.idItemCarrinho), backendItemId: i.idItemCarrinho, cartId: data.idCarrinho,
    productId: String(i.produtoId), size: (i as BackendCartItem & { tamanho?: string }).tamanho ?? "M", quantity: i.quantidade,
    customizations: i.personalizacoes.map((c) => ({ optionId: c.tipo.toLowerCase(), backendId: c.idPersonalizacao, details: detailsFromCustomization(c) })),
    subtotalCents: Math.round(Number(i.subtotal) * 100),
  }));
}

export function StoreProvider({ children }: { children: ReactNode }) {
  const [user, setUserState] = useState<User | null>(() => load("venus.user", null));
  const [cart, setCart] = useState<CartItem[]>([]);
  const [cartId, setCartId] = useState<number | null>(null);
  const [orders, setOrders] = useState<Order[]>(() => load("venus.orders", []));

  const refreshCart = async () => {
    if (!user) { setCart([]); setCartId(null); return; }
    try {
      let data: BackendCart;
      try { data = await cartApi.getByUser(user.idUsuario); }
      catch { data = await cartApi.create(user.idUsuario); }
      setCartId(data.idCarrinho); setCart(mapCart(data));
    } catch (e) { console.error("Não foi possível carregar o carrinho", e); }
  };

  useEffect(() => { if (user) void refreshCart(); else { setCart([]); setCartId(null); } }, [user?.idUsuario]);
  useEffect(() => { localStorage.setItem("venus.user", JSON.stringify(user)); }, [user]);
  useEffect(() => { localStorage.setItem("venus.orders", JSON.stringify(orders)); }, [orders]);

  const setUser = (u: User | null) => setUserState(u);

  const addToCart = async (i: Omit<CartItem, "key">) => {
    if (!user) throw new Error("Faça login para adicionar itens ao carrinho.");
    let cid = cartId;
    if (!cid) { const c = await cartApi.create(user.idUsuario).catch(() => cartApi.getByUser(user.idUsuario)); cid = c.idCarrinho; setCartId(cid); }
    const created = await cartApi.addItem(cid, Number(i.productId), i.quantity, i.size);
    await refreshCart();
    return { ...i, key: String(created.idItemCarrinho), backendItemId: created.idItemCarrinho, cartId: cid };
  };

  const addCustomization = async (itemId: number, payload: Omit<PersonalizationPayload, "itemCarrinhoId">) => {
    await customizationApi.add({ ...payload, itemCarrinhoId: itemId });
    await refreshCart();
  };

  const updateQty = async (key: string, q: number) => {
    const item = cart.find((i) => i.key === key); if (!item?.backendItemId) return;
    await cartApi.updateItem(item.backendItemId, Math.max(1, q)); await refreshCart();
  };

  const removeItem = async (key: string) => {
    const item = cart.find((i) => i.key === key); if (!item?.backendItemId) return;
    await cartApi.removeItem(item.backendItemId); await refreshCart();
  };

  const clearCart = () => setCart([]);

  const placeOrder = async (payment: Order["payment"]) => {
    if (!cartId) throw new Error("Carrinho não encontrado.");
    const checkout = await orderApi.checkout(cartId);
    await paymentApi.create(checkout.idPedido, paymentEnum(payment));
    const order: Order = {
      id: String(checkout.idPedido), createdAt: new Date().toISOString(), items: cart,
      totalCents: Math.round(Number(checkout.valorTotal) * 100), payment,
      status: statusLabel(checkout.status), hasCustomization: cart.some((i) => i.customizations.length > 0),
    };
    setOrders((os) => [order, ...os]);
    await refreshCart();
    return order;
  };

  const value: Store = { user, setUser, cart, cartId, refreshCart, addToCart, addCustomization, updateQty, removeItem, clearCart, orders, placeOrder };
  return <Ctx.Provider value={value}>{children}</Ctx.Provider>;
}

export function useStore() { const s = useContext(Ctx); if (!s) throw new Error("useStore fora do StoreProvider"); return s; }
export type AuthUser = User;
export function mapBackendUser(u: BackendUser): User { return { idUsuario: u.idUsuario, name: u.username, email: u.username }; }
