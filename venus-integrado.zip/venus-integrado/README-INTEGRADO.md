# Vênus — Front + Back integrados

Estrutura:

- `frontend/` — React + Vite + TanStack Router
- `backend/` — Spring Boot + JPA
- `INTEGRACAO.md` — mapa dos endpoints e pontos de atenção

## Ordem para executar

### Back

Abra `backend/` e execute:

```bash
./mvnw spring-boot:run
```

No Windows:

```bat
mvnw.cmd spring-boot:run
```

### Front

Abra `frontend/` e execute:

```bash
npm install
npm run dev
```

O front usa `http://localhost:8080` por padrão. Se precisar trocar, crie `.env` a partir de `.env.example`.
