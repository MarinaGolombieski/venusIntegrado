# Integração Vênus — Front React + Back Spring Boot

## 1. Como os dois projetos conversam

```text
React/Vite (5173)
      |
      | HTTP/JSON
      v
Spring Boot (8080)
      |
      v
JPA/Hibernate
      |
      v
H2 (desenvolvimento) / MySQL (perfil mysql)
```

O React não acessa o banco diretamente.

## 2. Configuração do front

Copie `.env.example` para `.env`:

```env
VITE_API_URL=http://localhost:8080
```

Depois:

```bash
npm install
npm run dev
```

## 3. Configuração do back

Desenvolvimento local usa H2 por padrão.

```bash
./mvnw spring-boot:run
```

Para MySQL:

```bash
./mvnw spring-boot:run -Dspring-boot.run.profiles=mysql
```

Variáveis opcionais:

```env
DB_URL=jdbc:mysql://localhost:3306/db_venus?useSSL=false&serverTimezone=America/Sao_Paulo&allowPublicKeyRetrieval=true
DB_USER=root
DB_PASSWORD=sua_senha
```

## 4. Endpoints usados pelo front

| Função | Método | Endpoint |
|---|---|---|
| listar produtos | GET | `/produtos` |
| produto | GET | `/produtos/{id}` |
| opções de personalização | GET | `/opcoes/personalizacoes` |
| cadastro | POST | `/usuarios` |
| login | POST | `/auth/login` |
| criar carrinho | POST | `/carrinhos` |
| buscar carrinho do usuário | GET | `/carrinhos/usuario/{usuarioId}` |
| adicionar item | POST | `/carrinhos/{id}/itens` |
| alterar quantidade | PUT | `/carrinhos/itens/{itemId}?quantidade=N` |
| remover item | DELETE | `/carrinhos/itens/{itemId}` |
| salvar personalização | POST | `/personalizacoes` |
| checkout | POST | `/pedidos/checkout` |
| criar pagamento | POST | `/pagamentos` |
| recomendações | GET | `/recomendacoes/produto/{id}` |
| prévia IA | POST | `/ia/preview` |

## 5. IA

`/ia/preview` é o contrato de integração, mas o provedor de geração de imagens ainda não foi escolhido/configurado. O React já chama o endpoint e trata o estado `NOT_CONFIGURED`.

A chave do provedor deve ficar no Spring Boot, nunca no código React.

## 6. Pontos que ainda precisam de decisão/ajuste

### Tamanho e estoque
O front possui estoque por tamanho (PP/P/M/G/GG). O back originalmente possuía apenas `estoque` agregado no produto e um `tamanho` único. Foi adicionado `tamanho` ao item do carrinho/pedido para não perder a escolha do cliente, mas o estoque ainda não é controlado separadamente por tamanho. Para produção, o banco deve ter estoque por tamanho.

### Dados de cadastro
O front coleta nome, e-mail, CPF, telefone e nascimento. O back original tinha apenas `username`, `senha` e `role`. A integração atual usa o e-mail como username. Se esses dados forem realmente necessários no sistema final, `Usuario`/DTOs devem receber os campos pessoais.

### Personalização
O back já suporta exatamente os tipos:
- `BORDADO_DESENHO`
- `BORDADO_ESCRITA`
- `TINGIMENTO`
- `APLICACAO_RENDA`
- `ALTERACAO_MANGA`

Os valores atuais do back são 5, 5, 10, 12 e 18 reais respectivamente. O front foi alinhado a esses valores.

### Preferências/recomendação
O back original não possuía uma entidade de preferências do usuário nem histórico de navegação. Foi criado um endpoint inicial de recomendação por produto, baseado nos dados que já existem. Para uma recomendação realmente personalizada por usuário/IA, ainda será necessário definir quais preferências serão armazenadas e conectar o provedor de IA/embeddings.

### Imagens
O back guarda imagens como bytes. Foi acrescentado `contentType` para que o navegador possa renderizá-las corretamente.

### Pagamento
O endpoint de pagamento atual registra e aprova/recusa pagamentos, mas não está conectado a um gateway real. O front continua sendo ambiente de teste.

### Autenticação
Foi criado `/auth/login` com BCrypt. Não existe JWT/session ainda. Para uma versão final, a autenticação deve evoluir para token/sessão e autorização por usuário.
